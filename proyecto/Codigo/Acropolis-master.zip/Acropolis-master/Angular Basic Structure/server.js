var express = require("express"),  
    app = express(),
    bodyParser  = require("body-parser"),
    methodOverride = require("method-override");
var path = require('path');
var jsonFile = require ('jsonfile');
var serverMethods = require('./serverMethods');
var MongoClient = require('mongodb').MongoClient;


    
    //mongoose = require('mongoose');

app.use(bodyParser.urlencoded({ extended: false }));  
app.use(bodyParser.json());  
app.use(methodOverride());
console.log(__dirname+'esta es la ruta');
//app.use(express.static(path.join(__dirname, 'views')));
app.use(express.static(path.join(__dirname + '/public'))); 
app.use('/server', express.static(__dirname + '/'));
//app.use(express.static(path.join(__dirname + 'public/views'))); 
//app.use(express.static(path.join(__dirname + '/assets'))); 

console.log('la ruta es: '+__dirname);
var router = express.Router();

/*
router.get('/', function(req, res) {    
   res.send("Hello World !");
});*/

//app.use(router);

/*app.get('/server/export', serverMethods.exportJSON);
app.get('/server/read', serverMethods.readJSON);
app.get('/server/getjson', serverMethods.getJSON);
app.get('/server/getschema', serverMethods.getSchema);


app.get('/server/getModulos', serverMethods.getModulos);
app.get('/server/getInversores', serverMethods.getInversores);
app.get('/server/getArreglos', serverMethods.getArreglos);*/
//Users
app.get('/server/getUsers', serverMethods.getUsers);
app.post('/server/getUser', serverMethods.getUser);

app.post('/server/insertUser',serverMethods.insertUser);
//Gyms
app.get('/server/getGyms', serverMethods.getGyms);
app.post('/server/insertGym',serverMethods.insertGym);
//app.post('/server/insert',serverMethods.insert);
//Routines
app.get('/server/getRoutines', serverMethods.getRoutines);
app.post('/server/insertRoutine',serverMethods.insertRoutine);
//News
app.get('/server/getNews', serverMethods.getNews);
app.post('/server/insertNews',serverMethods.insertNews);

MongoClient.connect("mongodb://localhost:27017/Acropolis", function(err, db) {
  if(err) {
    console.log('ERROR: connecting to Database. ' + err);
  }
  app.listen(3000, function() {
    console.log("Node server running on http://localhost:3000");
  });
});
