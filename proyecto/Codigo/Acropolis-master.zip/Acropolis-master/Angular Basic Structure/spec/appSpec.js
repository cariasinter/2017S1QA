describe('business logic', function(){



    
   // var Business_logic = require('../business_logic.js');
    var bsLogic;
    
    /*beforeEach(function() {  
       bsLogic = new Business_logic('hey'); 
    });*/
    
    it('says hello', function(){
        expect(Business_logic()).toEqual('Hello');
    })
    /*it("on time", function() {
    bsLogic.checkDateValidity("October 13, 2014 11:13:00", "October 12, 2014 11:13:00");
    
        
    expect(bsLogic).toBe(true);
  });
    it("expired date", function() {
    bsLogic.checkDateValidity("October 12, 2014 11:13:00", "October 13, 2014 11:13:00");
        
    expect(bsLogic).toBe(false);
  });
    it("barely on time", function() {
    bsLogic.checkDateValidity("October 13, 2014 11:13:00", "October 13, 2014 11:13:00");
        
    expect(bsLogic).toBe(true);
  });
    it("weight increase avaliable", function() {
    bsLogic.checkWeightsThreshold(10 , 10 );
        
    expect(bsLogic).toBe(true);
  });
     it("weight increase avaliable", function() {
    bsLogic.checkWeightsThreshold(5 , 10 );
        
    expect(bsLogic).toBe(false);
  });
    
     it("payment successful", function() {
    bsLogic.checkPayment(10000 , 10000 );
        
    expect(bsLogic).toBe(true);
  });
    it("payment unsuccessful", function() {
    bsLogic.checkPayment(1000 , 10000 );
        
    expect(bsLogic).toBe(false);
  });*/
})