(function(){

    function stringService(){

        var self = this;

        self.EMPTY = '';

    }
    app.service('stringService', [stringService]);

}).call(this);