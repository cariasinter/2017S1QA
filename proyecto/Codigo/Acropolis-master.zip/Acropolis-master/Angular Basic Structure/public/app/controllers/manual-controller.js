/*(function () {
    var app = angular.module('store2', []);
    
    app.controller('ManualController', function ($scope) {
        //this.products = gems;
        $scope.message = 'Look I am the manual controller!';
    }); 
    
})();
    /*