/*(function () {
    var app = angular.module('store2', []);
    
    app.controller('AutomaticController', function ($scope) {
        //this.products = gems;
        $scope.message = 'I am the automatic controller';
    }); 
    
    
})();*/