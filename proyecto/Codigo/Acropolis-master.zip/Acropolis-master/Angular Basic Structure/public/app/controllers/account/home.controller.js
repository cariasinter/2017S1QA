(function () {
    'use strict';
    function homeController($scope){
        $scope.start = function(){

        };
        $scope.start();

    }
    app.controller('homeController',['$scope', homeController]);
}(this));
