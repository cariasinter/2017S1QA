(function () {
    var app = angular.module('n-navbar', ['algoritmos']).
    constant('API_URL', "http://localhost:3000/");

    app.controller('FeedController', function ($scope, $http, DriverService) {
        console.log("Feed controller")
        $scope.feed_title;
        $scope.message = 'Indicaciones'; //para declarar las variables
        $scope.id = 1;
        $scope.obj;
        $scope.gym_name;
        $scope.date;
        $scope.description;
        $scope.author = localStorage.getItem("username");
        $scope.logged = false;

        $scope.insertFeed = function () { //funciones dentro del controller

            DriverService.insertFeed($scope.gym_name, $scope.feed_title, $scope.description, $scope.date, $scope.author);
            $scope.cleanFeed();

        }
        $scope.isUser = function () {
            if (localStorage.getItem("username")) {
                return true;
            }
            return false;
        }
        $scope.cleanFeed = function () {

            $scope.obj = "";
            $scope.gym_name = "";
            $scope.date = "";
            $scope.description = "";
            $scope.feed_title = "";
            $scope.author = "";
            $scope.init();
        }
        $scope.init = function () { //funciones dentro del controller


            if (localStorage.getItem("username"))
                $scope.logged = true;
            else
                $scope.logged = false;
            var onSuccess = function (response) {
                $scope.obj = response.data;
                $scope.error = '';
                console.log($scope.obj);
            };

            var onError = function (reason) {
                $scope.error = "Error in retrieving data.";
            };

            DriverService.getNews().then(onSuccess, onError);


        }
        $scope.init();
    });

    app.controller('RegisterController', function ($scope, DriverService) {
        $scope.title = 'Titulo Dashboard 0';
        console.log("Register Controller");

        /*$scope.first_name = "Jane";
        $scope.last_name = "Bishop";
        $scope.email = "janesemail@gmail.com";
        $scope.routine = "Adrenalina Multi Spa";
        $scope.gym = "Body Building";
        $scope.age = "32";
        $scope.weight = "105";
        $scope.height = "1.80";
        $scope.username = "jabishop";
        $scope.password = "qa2017";
        $scope.confirm_pass = "qa2017";*/

        $scope.first_name = "";
        $scope.last_name = "";
        $scope.email = "";
        $scope.routine = "";
        $scope.gym = "";
        $scope.age = "";
        $scope.weight = "";
        $scope.height = "";
        $scope.username = "";
        $scope.password = "";
        $scope.confirm_pass = "";
        $scope._id = "0"
        $scope.user_validation = function () {
            console.log('Register controller prueba');
            //DriverService.clean();//Por si ocupara alguna funcion del service
        }

        $scope.insertUser = function () { //funciones dentro del controller

            /*if ($scope.password !== $scope.confirm_password) {
                swal({
                    title: 'Las contraseñas no coinciden ',
                    animation: true,
                    type: 'error',
                    customClass: 'animated tada',
                    timer: 2000
                })
            } else {*/
            DriverService.insertUser2($scope, $scope.first_name, $scope.last_name, $scope.email, $scope.routine, $scope.gym, $scope.age, $scope.height, $scope.weight, $scope.username, $scope.password, $scope.confirm_pass);
            //}

        }


    });
    app.controller('StoreController', function ($scope, DriverService) { //Controlador del modulo de autenticacion;
        $scope.title = 'Titulo Dashboard 0';
        $scope.message = 'Everyone come and see how good I look!';
        $scope.username = "jurodriguez";
        $scope.password = 'qa2017';
        console.log("Store Controller");
        $scope.call_home = function () {
            //console.log("llamando algo");
            window.open('http://localhost:3000/#!/home');
        };

        $scope.sing_up = function () {
            location.replace('http://localhost:3000/#!/register');
            //console.log("ningun error");
        }

        $scope.user_validation = function () {
            var username = $scope.username;
            var password = $scope.password;
            //console.log("estamos probando la vista");
            //location.replace('http://localhost:3000/#!/news');
            DriverService.userValidation(username, password);
        }

        $scope.logOut = function () {
            localStorage.setItem("username", "");
            localStorage.setItem("password", "");

            location.replace('http://localhost:3000/#!/login');
        };


    });

    app.controller('HomeController', function ($scope, DriverService) {
        $scope.title = 'Titulo Dashboard 1';
        $scope.message = 'Indicaciones'; //para declarar las variables

        $scope.first_name = "";
        $scope.last_name = "";
        $scope.email = "";

        $scope.routine = "";
        $scope.gym = "";
        $scope.routineU = "";
        $scope.gymU = "";

        $scope.age = "";
        $scope.weight = "";
        $scope.height = "";
        $scope.username = "";
        $scope.password = "";
        $scope.confirm_pass = "";

        $scope.l_gyms = [];
        $scope.l_routines = [];
        $scope.l_available_gyms = [{
            "name": "Adrenalina Multi Spa"
        }, {
            "name": "PowerFlex"
        }, {
            "name": "Golden"
        }, {
            "name": "Eligon"
        }];
        $scope.l_available_routines = [{
            "name": "Body Building"
        }, {
            "name": "Tonificacion"
        }, {
            "name": "Control de Peso"
        }];

        $scope._id = "0"
        $scope.user;

        $scope.addGym = function () {

            for (var i = 0; i < $scope.l_gyms.length; i++) {
                if ($scope.l_gyms[i].name === $scope.gym) {
                    swal({
                        title: 'Ya se encuentra en tu lista favorita',
                        animation: true,
                        type: 'error',
                        customClass: 'animated tada',
                        timer: 2000
                    })
                    return;
                }
            }
            var gym = {
                name: $scope.gym
            };
            $scope.l_gyms.push(gym);
            console.log($scope.l_gyms);
        }
        $scope.addRoutine = function () {
            for (var i = 0; i < $scope.l_routines.length; i++) {
                if ($scope.l_routines[i].name === $scope.routine) {
                    swal({
                        title: 'Ya se encuentra en tu lista favorita',
                        animation: true,
                        type: 'error',
                        customClass: 'animated tada',
                        timer: 2000
                    })
                    return;
                }
            }
            var routine = {
                name: $scope.routine
            };
            $scope.l_routines.push(routine);
            console.log($scope.l_routines);
        }

        $scope.deleteGym = function () {


            for (var i = 0; i < $scope.l_gyms.length; i++) {
                if ($scope.l_gyms[i].name === $scope.gymU) {
                    $scope.l_gyms.splice(i, 1); //,$scope.gymU);
                    break;
                }
            }

            console.log($scope.l_gyms);
        }



        $scope.deleteRoutine = function () {
            for (var i = 0; i < $scope.l_routines.length; i++) {
                if ($scope.l_routines[i].name === $scope.routineU) {
                    $scope.l_routines.splice(i, 1); //,$scope.gymU);
                    break;
                }
            }

            console.log($scope.l_gyms);
        }

        $scope.init = function () {
            var username = localStorage.getItem("username");
            var password = localStorage.getItem("password");
            if (username && password) {

                var onSuccess = function (response) {
                    $scope.user = response.data;
                    $scope.error = '';
                    console.log($scope.user);
                    $scope.fillGaps();
                };

                var onError = function (reason) {
                    $scope.error = "Error in retrieving data.";
                };

                DriverService.getUserInfo(username, password).then(onSuccess, onError);


            } else {
                swal({
                    title: 'No ha iniciado sesión',
                    animation: true,
                    type: 'error',
                    customClass: 'animated tada',
                    timer: 2000
                })
            }
        }
        $scope.fillGaps = function () {

            $scope.first_name = $scope.user.first_name;
            $scope.last_name = $scope.user.last_name;
            $scope.email = $scope.user.email;
            $scope.routine = $scope.user.routine;
            $scope.gym = $scope.user.gym;
            $scope.age = $scope.user.age;
            $scope.weight = $scope.user.weight;
            $scope.height = $scope.user.height;
            $scope.username = $scope.user.username;
            $scope.password = $scope.user.password;
            $scope.confirm_pass = $scope.user.password;
            $scope.l_gyms = $scope.user.l_gyms;
            $scope.l_routines = $scope.user.l_routines;
            $scope._id = "0"
        }

        $scope.init();


    });

    app.controller('ManualController', function ($scope, DriverService) {
        console.log("Manual controller")
        $scope.title = 'Titulo Dashboard 1';
        $scope.message = 'Indicaciones';
        $scope.numeroGrafos = 0;
        $scope.busqueda = 0;
        $scope.numeroNodos = 1;
        $scope.peso = 1;
        $scope.inicio;
        $scope.final;
        $scope.nodo;

        DriverService.clean();

        $scope.getNodes = function () {
            return DriverService.nodes;
        }
        $scope.agregarNodo = function () {

            for (i = 0; i < $scope.numeroNodos; i++) {
                DriverService.insertNode();
            }

        }
        $scope.agregarArco = function () {
            if ($scope.peso) {
                DriverService.insertArc($scope.inicio, $scope.final, $scope.peso);
            }
        }

        $scope.eliminarNodo = function () {
            if ($scope.nodo) {
                DriverService.eliminarNodo($scope.nodo);
            }
        }
    });

    app.controller('AutomaticController', function ($scope, DriverService) {
        console.log("Automatic controller")
        $scope.title = 'Titulo Dashboard 2 ';
        $scope.message = 'Indicaciones: ';
        $scope.busqueda = 0;
        $scope.numeroGrafos = 0;
        $scope.nodo;

        DriverService.clean();

        $scope.eliminarNodo = function () {
            if ($scope.nodo) {
                DriverService.eliminarNodo($scope.nodo);
            }
        }

        $scope.generarGrafo = function () {
            DriverService.clean();
            DriverService.generado = false;
            if ($scope.numeroGrafos <= 1000) {
                DriverService.generateTree($scope.numeroGrafos);
            } else {
                DriverService.grafo = DriverService.generateGrafoMatriz($scope.numeroGrafos);


            }
        }


    });

    app.controller('LoadController', function ($scope) {
        console.log("Load controller")
        $scope.title = 'Titulo Dashboard 3';
        $scope.message = 'Indicaciones';
        $scope.busqueda = 0;


    });


    app.directive('nNavbar', function (DriverService) {
        return {
            restrict: 'E', //It means element
            templateUrl: 'views/n-navbar.html',
            controller: function () {
                this.tab = 0;

                this.logOut = function () {
                    localStorage.setItem("username", "");
                    localStorage.setItem("password", "");

                    location.replace('http://localhost:3000/#!/login');
                };

                this.clean = function () {
                    location.reload();
                }
                this.setearAlgoritmo = function (algoritmo) {
                    this.askNodes(algoritmo);

                }
                this.isSet = function (checkTab) {
                    return this.tab === checkTab;
                };

                this.setTab = function (activeTab) {
                    this.tab = activeTab;
                };
                this.nodes2 = [];

                this.askNodes = function (algoritmo) {

                    this.nodes = [];
                    this.tam = DriverService.nodes.length;
                    this.nodes = eval(JSON.stringify(DriverService.nodes));
                    if (algoritmo !== 'SA' && algoritmo !== 'TS') {

                        DriverService.nodosSwal = [];
                        for (var i = 0; i < this.tam; i++) {
                            //this.nodes2.push(this.nodes[i].label);
                            DriverService.nodosSwal.push(this.nodes[i].label);
                            //console.log(this.nodes[i].label);
                        }

                        //this.askNodes1('a');
                        swal.setDefaults({
                            input: 'select',
                            inputOptions: DriverService.nodosSwal,
                            confirmButtonText: 'Siguiente &rarr;',
                            showCancelButton: true,
                            confirmButtonColor: '#3085d6',
                            cancelButtonColor: '#d33',
                            animation: true,
                            progressSteps: ['1']
                        })

                        var steps = [

                            {
                                title: 'Seleccione',
                                text: 'Opc-1'
                  }
                ]

                        swal.queue(steps).then(function (result1) {
                            swal.setDefaults({
                                input: 'select',
                                inputOptions: DriverService.nodosSwal,
                                confirmButtonText: 'Siguiente &rarr;',
                                showCancelButton: true,
                                confirmButtonColor: '#3085d6',
                                cancelButtonColor: '#d33',
                                animation: false,
                                progressSteps: ['2']
                            })
                            var steps = [
                                {
                                    title: 'Seleccione ',
                                    text: 'Opc-2'
                  }
                ]
                            swal.queue(steps).then(function (result2) {
                                swal.resetDefaults()
                                var origen = DriverService.nodosSwal[eval(parseInt(result1))];
                                var destino = DriverService.nodosSwal[eval(parseInt(result2))];
                                swal({
                                    title: "Resolviendo",
                                    text: "Espere por favor",
                                    type: 'success',
                                    animation: true,
                                    timer: 3000,
                                    html: 'De origen: ' + origen + '<br>' +
                                        //JSON.stringify(result1) +
                                        ' A destino: ' + destino,
                                    //JSON.stringify(result2),
                                    showCancelButton: false,
                                    showConfirmButton: false
                                })
                                localStorage.setItem("origen", "");
                                localStorage.setItem("destino", "");

                                localStorage.setItem("origen", origen);
                                localStorage.setItem("destino", destino);
                                DriverService.menuAlgoritmos(algoritmo);
                                /*DriverService.origen=origen;
                                DriverService.destino=destino;*/


                            }, function () {

                                swal.resetDefaults()
                            })
                        }, function () {

                            swal.resetDefaults()

                        });

                    } else {
                        swal(
                            'Oops...',
                            'Modulo en desarrollo!',
                            'error'
                        )
                    }
                }



            },
            controllerAs: 'tab'
        };
    });

    app.service('DriverService', ['$http', function ($http) {


        this.generado = 1;
        this.obj;

        //Metodos de Generales-----------------------------------------------------------
        this.clean = function () {
            console.log("clean");

        };

        //Metodod de Home Controller----------------------------------------------------

        this.getUserInfo = function (username, password) {

            return $http.post('http://localhost:3000/server/getUser', {
                username: username,
                password,
                password
            });

        }


        //Metodos de Feed Controller-----------------------------------------------------

        this.insertFeed = function (gym_name, title, description, date, author) {
            console.log(gym_name, title, description, date);

            var setHeader = function (req) {
                req.setRequestHeader('content-type', 'application/json');
                req.setRequestHeader('accept', 'application/json');
            };

            $.ajax({
                type: 'POST',
                url: 'http://localhost:3000/server/insertNews',
                data: JSON.stringify({
                    '_id': 0,
                    'gym_name': gym_name,
                    'titulo': title,
                    'cuerpo': description,
                    'fecha': date,
                    'author': author,
                    'id_gym': ''
                }),
                beforeSend: setHeader,

                complete: function (data) {
                    //alert("Datos Ingresados Exitosamente!! ");
                    var obj = data.responseText;
                    if (obj) {
                        swal({
                            title: 'Inserción correcta',
                            animation: true,
                            type: 'success',
                            customClass: 'animated tada',
                            timer: 2000
                        })
                        $scope = null;
                        //                        console.log(obj);
                        //                        location.replace('http://localhost:3000/#!/home');
                    } else {
                        swal({
                            title: 'Inserción incorrecta',
                            animation: true,
                            type: 'error',
                            customClass: 'animated tada',
                            timer: 2000
                        })
                    }
                },
                error: function (e) {
                    swal({
                        title: 'Algo salio mal :( ',
                        animation: true,
                        type: 'error',
                        customClass: 'animated tada',
                        timer: 2000
                    })
                }

            })


        }

        this.getNews = function () {
            //console.log("Getting news!" + API_URL);
            var response;
            return $http({
                method: 'GET',
                url: 'http://localhost:3000/server/getNews',
                /*params: {
                    filterData: 'Test'
                },*/
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded'
                }
            });




            /*var setHeader = function (req) {
                req.setRequestHeader('content-type', 'application/json');
                req.setRequestHeader('accept', 'application/json');
            };
            $.ajax({
                type: 'GET',
                url: 'http://localhost:3000/server/getNews',
                beforeSend: setHeader,

                complete: function (data) {
                    //alert("Datos Ingresados Exitosamente!! ");
                    var obj = eval(data.responseText);
                    console.log(obj[0]);
                    return obj;
                },
                error: function (e) {
                    swal({
                        title: 'Algo salio mal :( ',
                        animation: true,
                        type: 'error',
                        customClass: 'animated tada',
                        timer: 2000
                    })
                }

            })*/


        }

        //Metodos de Register Controller-----------------------------------------------------

        this.insertUser2 = function ($scope, first_name, last_name, email, routine, gym, age, height, weight, username, password) {




            var setHeader = function (req) {
                req.setRequestHeader('content-type', 'application/json');
                req.setRequestHeader('accept', 'application/json');
            };

            $.ajax({
                type: 'POST',
                url: 'http://localhost:3000/server/insertUser',
                data: JSON.stringify({
                    'first_name': first_name,
                    'last_name': last_name,
                    'email': email,
                    'l_routine': [{
                        "name": ""
                    }],
                    'l_gym': [{
                        "name": ""
                    }],
                    'age': age,
                    'height': height,
                    'weight': weight,
                    'username': username,
                    'password': password
                }),
                beforeSend: setHeader,

                complete: function (data) {
                    //alert("Datos Ingresados Exitosamente!! ");
                    var obj = data.responseText;
                    if (obj) {
                        swal({
                            title: 'Inserción correcta',
                            animation: true,
                            type: 'success',
                            customClass: 'animated tada',
                            timer: 2000
                        })
                        $scope = null;
                        location.replace('http://localhost:3000/#!/login');
                    } else {
                        swal({
                            title: 'Inserción incorrecta',
                            animation: true,
                            type: 'error',
                            customClass: 'animated tada',
                            timer: 2000
                        })
                    }
                },
                error: function (e) {
                    swal({
                        title: 'Algo salio mal :( ',
                        animation: true,
                        type: 'error',
                        customClass: 'animated tada',
                        timer: 2000
                    })
                }

            })

        };


        //Metodos de Store Controller-----------------------------------------------------


        this.userValidation = function (username, password) {


            var username = username,
                password = password;

            var setHeader = function (req) {
                req.setRequestHeader('content-type', 'application/json');
                req.setRequestHeader('accept', 'application/json');
            };

            $.ajax({
                type: 'POST',
                url: 'http://localhost:3000/server/getUser',
                data: JSON.stringify({
                    'username': username,
                    'password': password
                }),
                beforeSend: setHeader,

                complete: function (data) {
                    //alert("Datos Ingresados Exitosamente!! ");
                    var obj = data.responseText;
                    if (obj) {

                        localStorage.setItem("username", username);
                        localStorage.setItem("password", password);
                        location.replace('http://localhost:3000/#!/home');

                    } else {
                        swal({
                            title: 'Credenciales incorrectas',
                            animation: true,
                            type: 'error',
                            customClass: 'animated tada',
                            timer: 2000
                        })
                    }
                },
                error: function (e) {
                    swal({
                        title: 'Algo salio mal :( ',
                        animation: true,
                        type: 'error',
                        customClass: 'animated tada',
                        timer: 2000
                    })
                }

            })
        }


    }])
})();
