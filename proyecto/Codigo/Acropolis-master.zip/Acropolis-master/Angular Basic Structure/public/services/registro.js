$(function() {
  $('input').floatlabel({labelEndTop:0});
});