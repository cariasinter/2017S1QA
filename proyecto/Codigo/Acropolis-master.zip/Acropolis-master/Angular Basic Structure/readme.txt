Las instrucciones para utilizar este proyecto son las siguientes:

1) Instalar las siguientes tecnologias
	a) MongoDB
	b) Node JS
	c) NPM
	d) Bower
2) En la raiz ejecutar desde el cmd el comando bower install
	*Esto es para instalar los modulos definidos en el bower.json
3) En la raiz ejecutar desde el cmd el comando npm install
	*Esto es para instalar los modulos definidos en el package.json
