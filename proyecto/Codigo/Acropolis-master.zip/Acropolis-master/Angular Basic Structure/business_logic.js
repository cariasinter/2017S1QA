Business_logic = function(){

};

Business_logic.prototype.checkDateValidity = function(actualDate, expiringDate) {
    var actualDate = new Date(actualDate) ;
    var expiringDate = new Date(expiringDate);
    if(Object.prototype.toString.call(expiringDate) === "[object Date]" ){
        if(isNaN(expiringDate.getTime())){
            return false;
        }
        else{
            if(actualDate >= expiringDate){ return true;}
            else{return false;}
        }
    }
    
};

Business_logic.prototype.checkWeightsThreshold = function(actualWeight, threshold) {
    //if(typeof actualWeight == 'number'  && typeof threshold = 'number'){
        if(actualWeight >= threshold ){ return true;}
        else{return false;}
    //}
    //else{return false;}
};

//Validity of the payment
Business_logic.prototype.checkPayment = function(payment, expectedPay){
    //if(typeof actualWeight == 'number'  && typeof threshold = 'number'){
        if(payment >= expectedPay){ return true;}
        else{return false;}
    //}
    //else{return false;}
};





















describe("Business_logic", function(){
    var bsLogic;
        
    beforeEach(function() {  
       var res;
       bsLogic = new Business_logic(); 
    });

    it("on time", function() {
    res = bsLogic.checkDateValidity(2211212, 12132312312);
    
        
    expect(res).toBe(false);
  });    
    
    it("on time", function() {
    res = bsLogic.checkDateValidity("asdadsdasdasdasdasdasdas", "adsdasdasdasdaso");
    
        
    expect(res).toBe(false);
  });    
    it("on time", function() {
    res = bsLogic.checkDateValidity("October 13, 2014 11:13:00", "saknfdalsfnsdlfnsldkfnsdlfnsdl");
    
        
    expect(res).toBe(true);
  });
    it("expired date", function() {
    res = bsLogic.checkDateValidity("October 12, 2014 11:13:00", "2014/11/08 11:13:00");
        
    expect(res).toBe(false);
  });
    it("barely on time", function() {
    res = bsLogic.checkDateValidity("October 13, 2014 11:13:00", "October 13, 2014 11:13:00");
        
    expect(res).toBe(true);
  });
    it("weight increase avaliable", function() {
    res = bsLogic.checkWeightsThreshold(10 , 10 );
       
    expect(res).toBe(true);
  });
    it("weight increase avaliable", function() {
    res = bsLogic.checkWeightsThreshold(10000000000000000000000000000000000000000000000001000000000000000000000000000000000000000000000000  , 10000000000000000000000000000000000000000000000001000000000000000000000000000000000000000000000000  );
       
    expect(res).toBe(true);
  });
    it("weight increase avaliable", function() {
    res = bsLogic.checkWeightsThreshold("1231231231" , "1231231231" );
       
    expect(res).toBe(true);
  });
    it("weight increase avaliable", function() {
    res = bsLogic.checkWeightsThreshold(5 , 10 );
        
    expect(res).toBe(false);
  });
    
    it("payment successful", function() {
    res = bsLogic.checkPayment(10000 , 10000);
        
    expect(res).toBe(true);
  });
    it("payment unsuccessful", function() {
    
    res = bsLogic.checkPayment(1000 , 10000 );
        
    expect(res).toBe(false);
  });
});


