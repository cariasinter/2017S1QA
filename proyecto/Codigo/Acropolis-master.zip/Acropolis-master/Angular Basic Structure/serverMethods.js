var jsonfile = require('jsonfile');
var express = require("express");
var mongo = require('mongodb');

var Server = mongo.Server,
    Db = mongo.Db,
    BSON = mongo.BSONPure;

var server = new Server('localhost', 27017, {
    auto_reconnect: true
});
db = new Db('Acropolis', server);

db.open(function (err, db) {
    if (!err) {
        console.log('Connected to "SESLab" database');
        /*var db2 = db.db('Lecheria'),
            db3 = db.db('Laboratory');
        lecheriaApp.setDB(db2);
        laboratoryApp.setDB(db3);*/
    } else {
        console.log(404, 'Error Connecting to "SESLab" database');
    }
});

exports.getUser = function (req, res) {
    var resource = req.body;
    db.collection('Users').findOne({
        username: req.body.username, password: req.body.password
    }, function (err, resource) {
        var error ="Usuario equivocado";
        if (err) throw error;
        res.send(200, resource);
    });
}

exports.getUsers = function (req, res) {
    db.collection('Users').find().toArray(function (err, doc_res) {
        if (err) throw err;
        if (!doc_res) console.log("No document found");
        res.send(200, doc_res);
    });

}

exports.getGyms = function (req, res) {
    db.collection('Gym').find().toArray(function (err, doc_res) {
        if (err) throw err;
        if (!doc_res) console.log("No document found");
        res.send(200, doc_res);
    });

}
exports.getRoutines = function (req, res) {
    db.collection('Routine').find().toArray(function (err, doc_res) {
        if (err) throw err;
        if (!doc_res) console.log("No document found");
        res.send(200, doc_res);
    });

}
exports.getNews = function (req, res) {
    var resource = req.body;
    db.collection('News').find().sort({ key: 1 }).toArray(function (err, doc_res) {
        if (err) throw err;
        if (!doc_res) console.log("No document found");
        res.send(200, doc_res);
    });

}
exports.insertNews = function (req, res) {
    var resource = req.body;
    db.collection('Index').findAndModify({
        _id: 0
    }, {}, {
        $inc: {
            news: 1
        }
    }, function (req2, res2) {
        var newId = res2.value.news;
        resource['_id'] = newId;
        var name = resource.gym_name;
        
        db.collection('Gym').findOne({
            name: name
        }, function (req3, res3) {



            var id_gym = res3;
            
            resource['id_gym'] = id_gym._id;
            db.collection('News').insert(resource, function (err, doc_res) {
                if (err) throw err;
                res.send(200, resource);
            });


        });


    });
}
exports.insertUser = function (req, res) {
    var resource = req.body;
    db.collection('Index').findAndModify({
        _id: 0
    }, {}, {
        $inc: {
            user: 1
        }
    }, function (req2, res2) {
        var newId = res2.value.user;

        resource['_id'] = newId;
        //resource['_id'] = resource['_id'];
        resource['age'] = parseInt(resource['age']);
        resource['weight'] = parseFloat(resource['weight']);
        resource['height'] = parseFloat(resource['height']);
        db.collection('Users').insert(resource, function (err, doc_res) {
            if (err) throw err;
            res.send(200, resource);
        });
    });

}

exports.insertGym = function (req, res) {
    var resource = req.body;
    db.collection('Index').findAndModify({
        _id: 0
    }, {}, {
        $inc: {
            gym: 1
        }
    }, function (req2, res2) {
        var newId = res2.value.gym;

        resource['_id'] = newId;
        db.collection('Gym').insert(resource, function (err, doc_res) {
            if (err) throw err;
            res.send(200, resource);
        });
    });

}
exports.insertRoutine = function (req, res) {
    var resource = req.body;
    db.collection('Routine').insert(resource, function (err, doc_res) {
        if (err) throw err;
        res.send(200, resource);
    });

}
