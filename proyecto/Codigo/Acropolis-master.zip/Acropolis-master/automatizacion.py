# -*- coding: utf-8 -*-
from selenium import selenium
import unittest, time, re

class automatizacion(unittest.TestCase):
    def setUp(self):
        self.verificationErrors = []
        self.selenium = selenium("localhost", 4444, "*chrome", "http://localhost:3000/")
        self.selenium.start()

    def test_automatizacion(self):
        sel = self.selenium
        sel.open("/#!/login")
        sel.click("css=input[type=\"submit\"]")
        sel.click("css=input[type=\"submit\"]")
        sel.click("link=Log out")
        sel.click("css=input[type=\"submit\"]")
        sel.click("css=input.btn.btn-primary")
        sel.select("id=user_time_zone", "label=Adrenalina Multi Spa")
        sel.type("//div[@id='main']/div/div/div/div/div/div/form/div[2]/textarea", "20/05/2017")
        sel.type("//div[@id='main']/div/div/div/div/div/div/form/div[3]/textarea", "TaeKwonDo")
        sel.type("//div[@id='main']/div/div/div/div/div/div/form/div[4]/textarea", "Clases de TaeKwonDo inscripciones listas")
        sel.click("name=say")
        sel.click("css=button.swal2-confirm.swal2-styled")
        sel.click("link=Log out")

    def tearDown(self):
        self.selenium.stop()
        self.assertEqual([], self.verificationErrors)

if __name__ == "__main__":
    unittest.main()
